from django.apps import AppConfig


class DnsanalysisConfig(AppConfig):
    name = 'dnsanalysis'
