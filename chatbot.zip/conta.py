# -*- coding: utf-8 -*-

from currency_converter import CurrencyConverter
from money import Money


conversor = CurrencyConverter(currency_file='eurofxref-hist.zip')


class Conta(object):
    __saldoCorrente = 1000
    __saldoPoupanca = 10000
    __limiteCredito = 2500
    __faturaCredito = 800
    __contaBloqueada = False

    def consultarCorrente(self):
        if self.__contaBloqueada:
            return 'Não é possível realizar esta operação \
pois sua conta está bloqueada.'

        saldo = Money(self.__saldoCorrente, 'BRL').format('pt_BR')
        return f'Saldo atual em sua conta corrente: {saldo}'

    def consultarPoupanca(self):
        if self.__contaBloqueada:
            return 'Não é possível realizar esta operação \
pois sua conta está bloqueada.'

        saldo = Money(self.__saldoPoupanca, 'BRL').format('pt_BR')
        return f'Saldo atual em sua conta poupança: {saldo}'

    def depositarCorrente(self, valor):
        if self.__contaBloqueada:
            return 'Não é possível realizar esta operação \
pois sua conta está bloqueada.'

        valor = valor['valor']

        if valor['amount'] <= 0:
            return 'Só é possível depositar valores positivos em sua conta.'
        else:
            self.__saldoCorrente += conversor.convert(valor['amount'],
                                                      valor['currency'],
                                                      'BRL')
            valor = Money(valor['amount'], valor['currency']).format('pt_BR')
            saldo = self.consultarCorrente()
            return f'Depositado {valor} em sua conta corrente.\n{saldo}'

    def depositarPoupanca(self, valor):
        if self.__contaBloqueada:
            return 'Não é possível realizar esta operação \
pois sua conta está bloqueada.'

        valor = valor['valor']

        if valor['amount'] <= 0:
            return 'Só é possível de positar valores positivos em sua conta.'
        else:
            self.__saldoPoupanca += conversor.convert(valor['amount'],
                                                      valor['currency'],
                                                      'BRL')
            valor = Money(valor['amount'], valor['currency']).format('pt_BR')
            saldo = self.consultarPoupanca()
            return f'Depositado {valor} em sua conta poupança.\n{saldo}'

    def sacarCorrente(self, valor):
        if self.__contaBloqueada:
            return 'Não é possível realizar esta operação \
pois sua conta está bloqueada.'

        valor = valor['valor']
        valor_c = conversor.convert(valor['amount'],
                                    valor['currency'],
                                    'BRL')

        if valor_c <= 0:
            return 'Só é possível de sacar valores positivos.'
        elif valor_c > self.__saldoCorrente:
            return 'Não é possível sacar valores maiores do que possui.'
        else:
            self.__saldoCorrente -= valor_c
            valor = Money(valor['amount'], valor['currency']).format('pt_BR')
            saldo = self.consultarCorrente()
            return f'Você sacou {valor} de sua conta corrente.\n{saldo}'

    def consultarFatura(self):
        if self.__contaBloqueada:
            return 'Não é possível realizar esta operação \
pois sua conta está bloqueada.'

        fatura = Money(self.__faturaCredito, 'BRL').format('pt_BR')
        return f'Valor da fatura atual: {fatura}'

    def pagarFatura(self, valor):
        if self.__contaBloqueada:
            return "Não é possível realizar esta operação \
pois sua conta está bloqueada."

        valor = valor['valor']
        valor_c = conversor.convert(valor['amount'],
                                    valor['currency'],
                                    'BRL')

        if valor_c <= 0:
            return 'Você não pode pagar valores negativos ou nulos.'
        elif valor_c > self.__saldoCorrente:
            return 'Você não possui dinheiro suficiente em sua conta.'
        elif valor_c > self.__faturaCredito:
            return 'Valor da fatura menor do que o pagamento.'
        else:
            self.__faturaCredito -= valor_c
            self.__saldoCorrente -= valor_c
            valor = Money(valor['amount'], valor['currency']).format('pt_BR')
            fatura = self.consultarFatura()
            saldo = self.consultarCorrente()
            return f'Realizado pagamento da fatura no valor de {valor}.\
{saldo}\n{fatura}'

    def bloquearConta(self):
        if self.__contaBloqueada:
            return 'Sua conta já está bloqueada.'
        else:
            self.__contaBloqueada = True
            return 'Sua conta foi bloqueada.'

    def desbloquearConta(self):
        if self.__contaBloqueada:
            self.__contaBloqueada = False
            return 'Sua conta foi desbloqueada.'
        else:
            return 'Sua conta já está desbloqueada.'

