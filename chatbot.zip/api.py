# -*- coding: utf-8 -*-

from flask import Flask, request
from json import dumps, loads
from conta import Conta


conta = Conta()

api = Flask(__name__)


@api.route('/', methods=['POST'])
def webhookPOST():
    data = loads(str(request.data, encoding='utf8'))

    for k, v in zip(data.keys(), data.values()):
        print(f'{k}: {v}')

    switch = {
        'consultarCorrente': conta.consultarCorrente,
        'consultarPoupanca': conta.consultarPoupanca,
        'depositarCorrente': conta.depositarCorrente,
        'depositarPoupanca': conta.depositarPoupanca,
        'sacarCorrente': conta.sacarCorrente,
        'consultarFatura': conta.consultarFatura,
        'pagarFatura': conta.pagarFatura,
        'bloquearConta': conta.bloquearConta,
        'desbloquearConta': conta.desbloquearConta,
        }

    response = {}

    query = data['queryResult']
    action, parameters = query['action'], query['parameters']

    if len(parameters):
        response['fulfillmentText'] = switch[action](parameters)
    else:
        response['fulfillmentText'] = switch[action]()

    return dumps(response)


@api.route('/', methods=['GET'])
def webhookGET():
    return 'get...'


api.run(port=80)
